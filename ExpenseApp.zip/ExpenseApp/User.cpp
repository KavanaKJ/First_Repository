#include "User.h"

User::User(QObject *parent)
    : QObject{parent}
{
  qDebug()<<Q_FUNC_INFO<<"User constructor"<<Qt::endl;
}

User::~User()
{
    qDebug()<<Q_FUNC_INFO<<"User constructor"<<Qt::endl;
}

QString User::phoneNumber() const
{
    return m_phoneNumber;
}

void User::setPhoneNumber(QString newPhoneNumber)
{
    m_phoneNumber = newPhoneNumber;
}

const QString &User::userName() const
{
    return m_userName;
}

void User::setUserName(const QString &newUserName)
{
    m_userName = newUserName;
}

const QString &User::passWord() const
{
    return m_passWord;
}

void User::setPassWord(const QString &newPassWord)
{
    m_passWord = newPassWord;
}
