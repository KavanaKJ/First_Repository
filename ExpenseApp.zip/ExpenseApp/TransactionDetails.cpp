#include "TransactionDetails.h"

TransactionDetails::TransactionDetails(QObject *parent)
    : QObject{parent}
{
    qDebug()<<"TransactionDetails constructor"<<Qt::endl;
    setTransactionStatus(false);
    setIncomeStatus(false);
    setSerialNo(0);
}

void TransactionDetails::print()
{
    qDebug()<<"---TransactionDetails--"<<Qt::endl;
}
TransactionDetails::~TransactionDetails()
{
    qDebug()<<"TransactionDetails Destructor"<<Qt::endl;
}

const QDate &TransactionDetails::date() const
{
    return m_date;
}

void TransactionDetails::setDate(const QDate &newDate)
{
    m_date = newDate;
}

int TransactionDetails::amount() const
{
    return m_amount;
}

void TransactionDetails::setAmount(int newAmount)
{
    m_amount = newAmount;
}

const QString &TransactionDetails::transactionType() const
{
    return m_transactionType;
}

void TransactionDetails::setTransactionType(const QString &newTransactionType)
{
    m_transactionType = newTransactionType;
}

bool TransactionDetails::getTransactionStatus() const
{
    return transactionStatus;
}

void TransactionDetails::setTransactionStatus(bool newTransactionStatus)
{
    transactionStatus = newTransactionStatus;
    emit transactionStatusChanged();
}

bool TransactionDetails::getIncomeStatus() const
{
    return incomeStatus;
}

void TransactionDetails::setIncomeStatus(bool newIncomeStatus)
{
    incomeStatus = newIncomeStatus;
    emit incomeStatusChanged();
}

int TransactionDetails::getSerialNo() const
{
    return serialNo;
}

void TransactionDetails::setSerialNo(int newSerialNo)
{
    serialNo = newSerialNo;
}





