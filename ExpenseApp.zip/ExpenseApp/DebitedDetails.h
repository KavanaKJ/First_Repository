#ifndef DEBITEDDETAILS_H
#define DEBITEDDETAILS_H

#include <TransactionDetails.h>
#include <QDebug>

class DebitedDetails : public TransactionDetails
{
public:
     DebitedDetails();
     void print();
     ~DebitedDetails();
private:

signals:

};

#endif // DEBITEDDETAILS_H
