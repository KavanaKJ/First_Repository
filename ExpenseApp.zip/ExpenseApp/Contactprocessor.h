#ifndef CONTACTPROCESSOR_H
#define CONTACTPROCESSOR_H

#include "BaseProcessor.h"
#include <QtAndroidExtras/QAndroidJniObject>
#include <QtAndroid>
#include <QDomDocument>
#include <QObject>
#include <QDebug>

class Contactprocessor : public BaseProcessor
{
public:
    explicit Contactprocessor(QObject *parent = nullptr);
    void readData();
    ~Contactprocessor();
signals:
};

#endif // CONTACTPROCESSOR_H
