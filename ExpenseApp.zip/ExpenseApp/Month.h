#ifndef MONTH_H
#define MONTH_H

#include <QObject>
#include <QDebug>
#include <TransactionModel.h>

class Month : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString monthname READ monthName  CONSTANT)
    Q_PROPERTY(TransactionModel* transactionModel READ transactionModel CONSTANT)
public:
    explicit Month(QObject *parent = nullptr);
    void setMessageDetails(QString transactionType,int amount,QDate date);
    TransactionModel* getTrasactionModel();
    ~Month();
    const QString &monthName() const;
    void setMonthName(const QString &newMonthName);
    TransactionModel *transactionModel() const;

private:
    TransactionModel *m_transactionModel;
    QString m_monthName;

signals:

};

#endif // MONTH_H
