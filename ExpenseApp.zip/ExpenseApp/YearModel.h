#ifndef YEARMODEL_H
#define YEARMODEL_H

#include <QAbstractListModel>
#include <QDebug>
#include <MonthModel.h>
#include <QQmlEngine>
#include <Year.h>
enum Years{
   YEAR=1
};
class YearModel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(Year* yearObj READ getCurrentYear CONSTANT)
    Q_PROPERTY(int val READ getVal WRITE setVal NOTIFY valChanged)

public:
    explicit YearModel(QObject *parent = nullptr);
    void print();
    QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const override;
    void setMessageDetails(QString transactionType,int amount,QDate date);
    Q_INVOKABLE void addTransactionDetails(QString type,QString amount, QString date);
    Q_INVOKABLE Year* getYearObj(int index);
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;
    void addTransactiontoModel(int slno,QString type,QString amount, QString date);
    void addIncome(int yindex,int mindex,int tindex,QString income);
    void removeIncome(int yindex,int mindex,int tindex,QString income);
    ~YearModel();
    Year* getCurrentYear();
    int getVal() const;
    void setVal(int newVal);

signals:
    void valChanged();
    void sendTransaction(QString type,QString amount, QString date);

private:
    Year *m_year;
    QMap<int,Year*> m_yearMap;
    int m_val;
};

#endif // YEARMODEL_H
