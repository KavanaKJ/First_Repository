#ifndef XMLPROCESSOR_H
#define XMLPROCESSOR_H

#include "BaseProcessor.h"
#include <QDomDocument>
#include <QtXml>
#include <QFile>

class XMLProcessor : public BaseProcessor
{
public:
    explicit XMLProcessor(QObject *parent = nullptr);
    void readData();
    ~XMLProcessor();
};

#endif // XMLPROCESSOR_H
