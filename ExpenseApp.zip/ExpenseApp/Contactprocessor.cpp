#include "Contactprocessor.h"

Contactprocessor::Contactprocessor(QObject *parent)
    : BaseProcessor{parent}
{
    qDebug()<<Q_FUNC_INFO<<"Contactprocessor Constructor"<<Qt::endl;
}

void Contactprocessor::readData()
{
    auto  result = QtAndroid::checkPermission(QString("android.permission.READ_CONTACTS"));
    if(result == QtAndroid::PermissionResult::Denied){
        qDebug()<<"don't have android.permission.READ_CONTACTS";
        QtAndroid::PermissionResultMap resultHash = QtAndroid::requestPermissionsSync(QStringList({"android.permission.READ_CONTACTS"}));
        if(resultHash["android.permission.READ_CONTACTS"] == QtAndroid::PermissionResult::Denied)
        {
            qDebug()<<"couldn't get android.permission.READ_CONTACTS";
        }
    }
    if(QAndroidJniObject::isClassAvailable("com/example/contacts/fetch/FetchClass")) {
        qDebug() << "JAVA CLASS AVAILABLE!";
    }
    else {
        qDebug() << "JAVA CLASS UNAVAIABLE!";
    }
    QAndroidJniObject str = QAndroidJniObject::callStaticObjectMethod("com/example/contacts/fetch/FetchClass", "getContacts", "(Landroid/content/Context;)Ljava/lang/String;", QtAndroid::androidActivity().object<jobject>());
    QDomDocument document;
    document.setContent(str.toString());
    QDomElement root,contact,name,phone;
    QString pname,personPhone;
    root =document.documentElement();
    QString rootname = root.tagName();
    qDebug()<<"root name"<<rootname<<Qt::endl;
    contact=root.firstChild().toElement();

        while(!contact.isNull())
        {
            if(contact.tagName()=="item")
            {
                name=contact.firstChild().toElement();
                if(name.tagName()=="name")
                {
                    pname=name.firstChild().toText().data();
                    phone=name.nextSibling().toElement();
                }
                if(phone.tagName()=="number")
                {
                    personPhone=phone.firstChild().toText().data();
                    personPhone=personPhone.replace(" ","");
                }
            }
            contact=contact.nextSibling().toElement();
            emit sendContactData(pname,personPhone);
       }
}

Contactprocessor::~Contactprocessor()
{
    qDebug()<<Q_FUNC_INFO<<"Contactprocessor Destructor"<<Qt::endl;
}
