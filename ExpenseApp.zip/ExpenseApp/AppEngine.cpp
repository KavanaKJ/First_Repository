#include "AppEngine.h"

AppEngine::AppEngine(QObject *parent)
    : QObject{parent}
{
 qDebug()<<"AppEngine Constructor"<<Qt::endl;
}

void AppEngine::init(QQmlApplicationEngine* engine)
{
    ExpenseManager *expenseManager =new ExpenseManager;
    QQmlEngine::setObjectOwnership(expenseManager,QQmlEngine::CppOwnership);
 engine->rootContext()->setContextProperty("expenseModel",expenseManager);
 qmlRegisterUncreatableType<YearModel>("YearModel",1,0,"YearModel","not creating object in qml");
 qmlRegisterUncreatableType<Year>("Year",1,0,"Year","not creating object in qml");
 qmlRegisterUncreatableType<MonthModel>("MonthModel",1,0,"MonthModel","not creating object in qml");
 qmlRegisterUncreatableType<Month>("Month",1,0,"Month","not creating object in qml");
 qmlRegisterUncreatableType<TransactionModel>("TransactionModel",1,0,"TransactionModel","not creating object in qml");
 qmlRegisterUncreatableType<TransactionDetails>("TransactionDetails",1,0,"TransactionDetails","not creating object in qml");
 qmlRegisterUncreatableType<Split>("Split",1,0,"Split","not creating object in qml");
 qmlRegisterUncreatableType<ContactsModel>("ContactsModel",1,0,"ContactsModel","not creating object in qml");
 qmlRegisterUncreatableType<UserRegistration>("UserRegistration",1,0,"UserRegistration","not creating object in qml");
 qmlRegisterUncreatableType<MessageProcessor>("MessageProcessor",1,0,"MessageProcessor","not creating object in qml");
 qmlRegisterUncreatableType<DBProcessor>("DBProcessor",1,0,"DBProcessor","not creating object in qml");
 qmlRegisterUncreatableType<GroupModel>("GroupModel",1,0,"GroupModel","not creating object in qml");
 qmlRegisterUncreatableType<SelectedContactsModel>("SelectedContactsModel",1,0,"SelectedContactsModel","not creating object in qml");

}
AppEngine::~AppEngine()
{
qDebug()<<"AppEngine Destructor"<<Qt::endl;
}
