#include "YearModel.h"

YearModel::YearModel(QObject *parent)
    : QAbstractListModel(parent)
{
    qDebug()<<Q_FUNC_INFO<<"YearModel Constructor"<<Qt::endl;
    QDate date=QDate::currentDate();
    m_year=new Year;
    QQmlEngine::setObjectOwnership(m_year,QQmlEngine::CppOwnership);
    m_year->setYear(date.year());
    m_yearMap.insert(date.year(),m_year);
    m_val=0;
}

void YearModel::print()
{
    qDebug()<<"yearList size--"<<m_yearMap.size()<<Qt::endl;
    for(auto it=m_yearMap.begin();it!=m_yearMap.end();it++)
    {
        qDebug()<<"year--"<<it.key()<<Qt::endl;
        if(it.key()==0)
        {
            m_yearMap.remove(0);
        }
    }
}

QVariant YearModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    // FIXME: Implement me!
}

void YearModel::setMessageDetails(QString transactionType, int amount, QDate date)
{
    qDebug()<<"setMessageDetails---"<<date<<"size of map"<<m_yearMap.size()<<Qt::endl;
    auto it=m_yearMap.find(date.year());
    if(it!=m_yearMap.end())
    {
        it.value()->monthModel()->setMessageDetails(transactionType,amount,date);
    }
    else{
        m_year=new Year;
        QQmlEngine::setObjectOwnership(m_year,QQmlEngine::CppOwnership);
        m_year->setYear(date.year());
        m_year->monthModel()->setMessageDetails(transactionType,amount,date);
        m_yearMap.insert(date.year(),m_year);
    }
    m_val=m_yearMap.size();
    print();
}

void YearModel::addTransactionDetails(QString type,QString amount, QString date)
{
    qDebug()<<"add transaction to database"<<Qt::endl;
    emit sendTransaction(type,amount,date);
}

Year *YearModel::getYearObj(int index)
{
    return m_yearMap.values().at(index);
}

int YearModel::rowCount(const QModelIndex &parent) const
{
    return m_yearMap.values().size();
}
QVariant YearModel::data(const QModelIndex &index, int role) const
{
    int row =index.row();
    Year *y=m_yearMap.values().at(row);
    switch(role){
    case YEAR:return y->getyear();
    }
    return QVariant();
}

QHash<int, QByteArray> YearModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[YEAR]="year";
    return roles;
}

void YearModel::addTransactiontoModel(int slno,QString type,QString amount, QString date)
{
    qDebug()<<"addTransactiontoModel called"<<Qt::endl;
    QStringList datelist=date.split('/');
    QDate date1;
    if(datelist.length()==3)
    {
        int d=datelist.at(0).toInt();
        int m=datelist.at(1).toInt();
        int y=datelist.at(2).toInt();
        date1.setDate(y,m,d);
        for(auto it=m_yearMap.begin();it!=m_yearMap.end();it++)
        {
            if(it.key()==y)
            {
                it.value()->monthModel()->addTransactionDetails(slno,type,amount,date1);
            }
        }
        if(!m_yearMap.contains(y))
        {
            m_year=new Year;
            m_year->setYear(y);
            m_year->monthModel()->addTransactionDetails(slno,type,amount,date1);
            m_yearMap.insert(y,m_year);
        }
        m_val=m_yearMap.size();
    }
    else{
        qDebug()<<"Invalid date format"<<Qt::endl;
    }
}

void YearModel::addIncome(int yindex, int mindex, int tindex, QString income)
{
    qDebug()<<"addIncome"<<income<<Qt::endl;
    auto transactionModel= m_yearMap.values().at(yindex)->monthModel()->getMonth(mindex)->transactionModel();
    auto transaction= m_yearMap.values().at(yindex)->monthModel()->getMonth(mindex)->transactionModel()->getTransactionObj(tindex);
//    qDebug()<<"addIncome---------------------"<<transaction->amount()<<income<<Qt::endl;
    if(transaction->getIncomeStatus()==false)
    {
        transaction->setIncomeStatus(true);
        transaction->setTransactionStatus(true);
        transactionModel->setincome(income.toInt());
    }else{
        qDebug()<<"already amount has set as income"<<Qt::endl;
    }
}

void YearModel::removeIncome(int yindex, int mindex, int tindex, QString income)
{
    qDebug()<<"removeIncome"<<income<<Qt::endl;
    auto transactionModel= m_yearMap.values().at(yindex)->monthModel()->getMonth(mindex)->transactionModel();
    auto transaction= m_yearMap.values().at(yindex)->monthModel()->getMonth(mindex)->transactionModel()->getTransactionObj(tindex);
    if(transaction!=nullptr)
    {
        if(transaction->getIncomeStatus()==true){
            transactionModel->deleteFromIncome(income.toInt());
            transaction->setIncomeStatus(false);
            transaction->setTransactionStatus(false);
        }else{
            qDebug()<<"income is already removed"<<Qt::endl;
        }
    }else{
        qDebug()<<"null"<<Qt::endl;
    }
}

YearModel::~YearModel()
{
    qDebug()<<Q_FUNC_INFO<<"YearModel Constructor"<<Qt::endl;
}

Year *YearModel::getCurrentYear()
{
    int d=QDate::currentDate().year();
    qDebug()<<"current year---"<<d<<Qt::endl;
    for(auto it=m_yearMap.begin();it!=m_yearMap.end();it++)
    {
        if(it.key()==d)
        {
            return it.value();
        }
    }
}

int YearModel::getVal() const
{
    return m_val;
}

void YearModel::setVal(int newVal)
{
    if (m_val == newVal)
        return;
    m_val = newVal;
    emit valChanged();
}
