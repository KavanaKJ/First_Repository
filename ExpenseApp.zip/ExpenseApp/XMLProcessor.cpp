#include "XMLProcessor.h"

XMLProcessor::XMLProcessor(QObject *parent)
    : BaseProcessor{parent}
{
 qDebug()<<Q_FUNC_INFO<<Qt::endl;
}

void XMLProcessor::readData()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
//    QString path=QCoreApplication::applicationDirPath();
//    path=path+"/ContactListxml.xml";
//    qDebug()<<path<<Qt::endl;
        QFile file;
//        QString currentpath=QDir::currentPath()+"/ContactListxml.txt";
        file.setFileName(":/Files/ContactListxml.xml");

    qDebug()<<"xml file path--"<<file.fileName()<<Qt::endl;
    if (!file.open(QIODevice::ReadOnly ))
    {
        qDebug()<<"Error loading the file"<<Qt::endl;
    }
    QDomDocument document;
    document.setContent(&file);
    QDomElement root,contact,name,phone;
    QString pname,personPhone;
    root =document.documentElement();
    QString rootname = root.tagName();
    qDebug()<<"root name"<<rootname<<Qt::endl;
     contact=root.firstChild().toElement();
    while(!contact.isNull())
    {
      if(contact.tagName()=="contact")
      {
          name=contact.firstChild().toElement();
          if(name.tagName()=="name")
          {
              pname=name.firstChild().toText().data();
//              qDebug()<<"name--"<<pname<<Qt::endl;
              phone=name.nextSibling().toElement();
          }
           if(phone.tagName()=="phone")
          {
             personPhone=phone.firstChild().toText().data();
//             qDebug()<<"phone--"<<personPhone<<Qt::endl;
          }
      }
      contact=contact.nextSibling().toElement();
      emit sendContactData(pname,personPhone);
    }
    file.close();
}

XMLProcessor::~XMLProcessor()
{
 qDebug()<<Q_FUNC_INFO<<Qt::endl;
}
