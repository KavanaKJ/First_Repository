#include "ContactsModel.h"

ContactsModel::ContactsModel(QObject *parent)
    : QAbstractListModel(parent)
{
    qDebug()<<"ContactsModel constructor"<<Qt::endl;
    contactListStatus=false;
    contactS=false;
    contacts=new Contacts;
    contacts->setName("Me");
    m_contactList.append(contacts);
}

void ContactsModel::setContacts(QString name, QString phone)
{
     contacts=new Contacts;
     QQmlEngine::setObjectOwnership(contacts,QQmlEngine::CppOwnership);
     contacts->setName(name);
     contacts->setPhoneNo(phone);
     addContactsToList(contacts);
}

void ContactsModel::addContactsToList(Contacts *c)
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    if(m_contactList.isEmpty())
    {
        m_contactList.append(c);
    }
    else if(!m_contactList.empty()){
        for(auto it=m_contactList.begin();it!=m_contactList.end();it++)
        {
           if((*it)->phoneNo()==c->phoneNo())
           {
              contactS=true;
              break;
           }
           else{
              contactS=false;
           }
        }
        if(contactS==false)
        {
            qDebug()<<"appending"<<c->name()<<Qt::endl;
            m_contactList.append(c);
        }
    }else{

    }
    qDebug()<<"contact list size "<<m_contactList.size()<<Qt::endl;
    sortContacts();
//    print();
}
QVariant ContactsModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    // FIXME: Implement me!
}

void ContactsModel::print()
{
    for(auto it=m_contactList.begin();it!=m_contactList.end();it++)
    {
        qDebug()<<"Name--"<<(*it)->name()<<Qt::endl;
        qDebug()<<"Phone---"<<(*it)->phoneNo()<<Qt::endl;
    }
}

int ContactsModel::rowCount(const QModelIndex &parent) const
{
    qDebug()<<Q_FUNC_INFO<<"row count______________"<<m_contactList.size()<<Qt::endl;
    return m_contactList.size();
}

QHash<int, QByteArray> ContactsModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[NAME]="contactName";
    roles[PHONE]="phoneNo";
    return roles;
}

QVariant ContactsModel::data(const QModelIndex &index, int role) const
{
    int row =index.row();
    Contacts *c = m_contactList.at(row);
    switch(role)
    {
    case NAME:return c->name();
    case PHONE:return c->phoneNo();
    }
    return QVariant();
}

void ContactsModel::sortContacts()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    qSort(m_contactList.begin(), m_contactList.end(),
          [](const Contacts* a, const Contacts* b) -> bool { return a->name() < b->name(); });
}

ContactsModel::~ContactsModel()
{
    qDebug()<<"ContactsModel Destructor"<<Qt::endl;
}

const QList<Contacts *> &ContactsModel::contactList() const
{
    return m_contactList;
}

Contacts *ContactsModel::getContact() const
{
    return contacts;
}

void ContactsModel::setContact(Contacts *newContact)
{
    contacts = newContact;
}
