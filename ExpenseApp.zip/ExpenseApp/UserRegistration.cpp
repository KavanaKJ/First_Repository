#include "UserRegistration.h"

UserRegistration::UserRegistration(QObject *parent)
    : QObject{parent}
{
    qDebug()<<Q_FUNC_INFO<<"UserRegistration constrcuctor"<<Qt::endl;
    m_user=nullptr;
    setLoginStatus(false);
}

void UserRegistration::init()
{

 m_user=new User;
 m_user->setUserName("");
 m_user->setPhoneNumber("");
 m_user->setPassWord("");
 m_loginStatus=false;

}

void UserRegistration::checkLoginDetails(QString name, QString password)
{
    if(m_user==nullptr){
        qDebug()<<"no user"<<Qt::endl;
         setLoginStatus(false);
      }
       else if(m_user->userName()==name && m_user->passWord()==password)
       {
          setLoginStatus(true);
       }else{
          setLoginStatus(false);
    }
}
void UserRegistration::signUp(QString name, QString no, QString password)
{
 emit sendUserDetails(name,no,password);
}
UserRegistration::~UserRegistration()
{
    qDebug()<<Q_FUNC_INFO<<"UserRegistration Destrcuctor"<<Qt::endl;
}

bool UserRegistration::getloginStatus() const
{
    return m_loginStatus;
}

void UserRegistration::addUserDetails(QString name, QString no, QString password)
{
    qDebug()<<Q_FUNC_INFO<<name<<Qt::endl;
     m_user=new User;
     m_user->setUserName(name);
     m_user->setPhoneNumber(no);
     m_user->setPassWord(password);
     qDebug()<<"_______________________________________"<<Qt::endl;
     setLoginStatus(false);
}

void UserRegistration::setLoginStatus(bool newLoginStatus)
{
    if (m_loginStatus == newLoginStatus)
        return;
    qDebug()<<Q_FUNC_INFO<<"------"<<newLoginStatus<<Qt::endl;
    m_loginStatus = newLoginStatus;
    emit loginStatusChanged();
}

User *UserRegistration::getuser() const
{
    return m_user;
}
