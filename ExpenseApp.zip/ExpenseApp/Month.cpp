#include "Month.h"

Month::Month(QObject *parent)
    : QObject{parent}
{
    qDebug()<<"Month constructor"<<Qt::endl;
    m_transactionModel=new TransactionModel;
}

void Month::setMessageDetails(QString transactionType,int amount,QDate date)
{
    m_transactionModel->setMessage(transactionType,amount,date);
}

TransactionModel *Month::getTrasactionModel()
{
 return m_transactionModel;
}

Month::~Month()
{
    qDebug()<<"Month Destructor"<<Qt::endl;
}

const QString &Month::monthName() const
{
    return m_monthName;
}

void Month::setMonthName(const QString &newMonthName)
{
    m_monthName = newMonthName;
}

TransactionModel *Month::transactionModel() const
{
    return m_transactionModel;
}
