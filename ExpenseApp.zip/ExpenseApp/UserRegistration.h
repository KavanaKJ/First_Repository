#ifndef USERREGISTRATION_H
#define USERREGISTRATION_H

#include <QObject>
#include<QDebug>
#include <User.h>

class UserRegistration : public QObject
{
    Q_OBJECT
    Q_PROPERTY(User* user READ getuser CONSTANT)
    Q_PROPERTY(bool loginStatus READ getloginStatus WRITE setLoginStatus NOTIFY loginStatusChanged)
public:
    explicit UserRegistration(QObject *parent = nullptr);
    void init();
    Q_INVOKABLE void checkLoginDetails(QString name, QString password);
    Q_INVOKABLE void signUp(QString name,QString no,QString password);
    ~UserRegistration();
    bool getloginStatus() const;
    void addUserDetails(QString name,QString no,QString password);
    void setLoginStatus(bool newLoginStatus);
    User *getuser() const;
private:
    User *m_user;
    bool m_loginStatus;

signals:
    void loginStatusChanged();
    void sendUserDetails(QString name,QString no,QString password);
};

#endif // USERREGISTRATION_H
