#include "SelectedContactsModel.h"

SelectedContactsModel::SelectedContactsModel(QObject *parent)
    : QAbstractListModel{parent}
{
  qDebug()<<Q_FUNC_INFO<<"SelectedContactsModel Constructor"<<Qt::endl;
}

int SelectedContactsModel::rowCount(const QModelIndex &parent) const
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
  return m_selectedContacts.size();
}

QHash<int, QByteArray> SelectedContactsModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[NAME]="contactName";
    roles[PHONE]="phoneNo";
    return roles;
}

QVariant SelectedContactsModel::data(const QModelIndex &index, int role) const
{
    int row =index.row();
    Contacts *c = m_selectedContacts.at(row);
    switch(role)
    {
    case NAME:return c->name();
    case PHONE:return c->phoneNo();
    }
    return QVariant();
}

void SelectedContactsModel::getContactDetail(Contacts* c)
{
  qDebug()<<Q_FUNC_INFO<<c<<Qt::endl;
     if(m_selectedContacts.contains(c))
     {
         qDebug()<<"Already has object"<<Qt::endl;
     }else{
         (c)->setSelectedContact(true);
       m_selectedContacts.append(c);
     }
// print();
}
void SelectedContactsModel::removeContactsfromGroup(Contacts *c)
{
    if(m_selectedContacts.contains(c))
    {
      c->setSelectedContact(false);
     m_selectedContacts.removeOne(c);
     qDebug()<<"object deleted---"<<m_selectedContacts.size()<<Qt::endl;
    }
}

void SelectedContactsModel::print()
{
 for(auto it=m_selectedContacts.begin();it!=m_selectedContacts.end();it++)
 {
  qDebug()<<"selectedContacts list"<<(*it)->name()<<Qt::endl;
 }
}

SelectedContactsModel::~SelectedContactsModel()
{
    qDebug()<<Q_FUNC_INFO<<"SelectedContactsModel Constructor"<<Qt::endl;
}

const QList<Contacts *> &SelectedContactsModel::getselectedContacts() const
{
    return m_selectedContacts;
}
