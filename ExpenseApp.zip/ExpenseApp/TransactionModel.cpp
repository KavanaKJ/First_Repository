#include "TransactionModel.h"

TransactionModel::TransactionModel(QObject *parent)
    : QAbstractListModel(parent)
{
    qDebug()<<"TransactionModel constructor"<<Qt::endl;
    m_income=0;
}

void TransactionModel::setMessage(QString transactionType,int amount,QDate date)
{
    if(transactionType=="Debited")
    {
        m_transaction = new DebitedDetails;
        QQmlEngine::setObjectOwnership(m_transaction,QQmlEngine::CppOwnership);
        m_transaction->setDate(date);
        m_transaction->setAmount(amount);
        m_transaction->setTransactionType(transactionType);
    }
    else if(transactionType=="Credited")
    {
        m_transaction = new CreditedDetails;
        QQmlEngine::setObjectOwnership(m_transaction,QQmlEngine::CppOwnership);
        m_transaction->setDate(date);
        m_transaction->setAmount(amount);
        m_transaction->setTransactionType(transactionType);
        qDebug()<<"Credit Amout"<<m_transaction->amount()<<Qt::endl;
    }
    m_transactionList.append(m_transaction);
    print();
}

void TransactionModel::print()
{
    qDebug()<<" Transaction list size "<<m_transactionList.size()<<Qt::endl;
}

void TransactionModel::addTransactionDetails(int slno,QString type,QString amount, QDate date)
{
    qDebug()<<"Adding Transaction details"<<Qt::endl;
    if(type=="Debited"){
        m_transaction=new DebitedDetails;
        QQmlEngine::setObjectOwnership(m_transaction,QQmlEngine::CppOwnership);
        m_transaction->setTransactionType("Debited");
        m_transaction->setAmount(amount.toInt());
        m_transaction->setDate(date);
        m_transaction->setSerialNo(slno);
    }else if(type=="Credited")
    {
        m_transaction=new CreditedDetails;
        QQmlEngine::setObjectOwnership(m_transaction,QQmlEngine::CppOwnership);
        m_transaction->setTransactionType("Credited");
        m_transaction->setAmount(amount.toInt());
        m_transaction->setDate(date);
        m_transaction->setSerialNo(slno);
    }
    beginInsertRows(QModelIndex(),0,0);
    m_transactionList.push_front(m_transaction);
    endInsertRows();
}

QVariant TransactionModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    // FIXME: Implement me!
}

int TransactionModel::rowCount(const QModelIndex &parent) const
{
    return m_transactionList.size();
}

QHash<int, QByteArray> TransactionModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[AMOUNT]="Tamount";
    roles[TYPE]="Ttype";
    roles[DATE]="Tdate";
    return roles;
}

QVariant TransactionModel::data(const QModelIndex &index, int role) const
{
    int row =index.row();
    TransactionDetails* t=m_transactionList.at(row);
    switch (role) {
    case AMOUNT:return t->amount();
    case TYPE:return t->transactionType();
    case DATE:return t->date();
    }
    return QVariant();
}

TransactionModel::~TransactionModel()
{
    qDebug()<<"TransactionModel Destructor"<<Qt::endl;
}

const QList<TransactionDetails *> &TransactionModel::transactionList() const
{
    return m_transactionList;
}

int TransactionModel::gettotalDebit()
{
    m_totalDebit=0;
    for(auto it=m_transactionList.begin();it!=m_transactionList.end();it++)
    {
        if((*it)->transactionType()=="Debited")
        {
            m_totalDebit+=(*it)->amount();
        }
    }
    return m_totalDebit;
}

void TransactionModel::totalIncome(/*TransactionDetails *transaction*/int yIndex,int mIndex,int tIndex,QString income)
{
    income = income.replace("₹","");
    income = income.replace(".00","");
    emit sendIncome(yIndex,mIndex,tIndex,income);
}
void TransactionModel::setincome(int income)
{
    m_income += income;
    qDebug()<<"income--------"<<m_income<<income<<Qt::endl;
}

void TransactionModel::deleteFromIncome(int income)
{
            qDebug()<<"deleteFromIncome"<<m_income<<Qt::endl;
            m_income -= income;
}

TransactionDetails *TransactionModel::getTransactionObj(int index)
{
    return m_transactionList.at(index);
}

void TransactionModel::setTotalDebit(int newTotalDebit)
{
    m_totalDebit = newTotalDebit;
    emit totaldebitChanged();
}

int TransactionModel::getTotalIncome()
{
    qDebug()<<"getTotalIncome called"<<m_income<<Qt::endl;
    return m_income;
}

void TransactionModel::setTotalIncome(int newTotalIncome)
{
    m_income = newTotalIncome;
    emit incomeChanged();
}


