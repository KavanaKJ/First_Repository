#ifndef BASEPROCESSOR_H
#define BASEPROCESSOR_H

#include <QObject>
#include <QDebug>
#include <QDate>

class BaseProcessor : public QObject
{
    Q_OBJECT
public:
    explicit BaseProcessor(QObject *parent = nullptr);
     virtual void readData()=0;
    ~BaseProcessor();

signals:
     void sendMessageData(QString transactionType,int debit,QDate date);
     void sendContactData(QString name,QString phone);
};

#endif // BASEPROCESSOR_H
