#ifndef TRANSACTIONDETAILS_H
#define TRANSACTIONDETAILS_H

#include <QObject>
#include<QDebug>
#include<QDate>
#include<QTime>

class TransactionDetails : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int amount READ amount CONSTANT)
    Q_PROPERTY(QString transactionType READ transactionType CONSTANT)
    Q_PROPERTY(bool transactionstatus READ getTransactionStatus WRITE setTransactionStatus NOTIFY transactionStatusChanged)
    Q_PROPERTY(bool incomeStatus READ getIncomeStatus WRITE setIncomeStatus NOTIFY incomeStatusChanged)
    Q_PROPERTY(QDate date READ date CONSTANT)
public:
    explicit TransactionDetails(QObject *parent = nullptr);
    virtual void print();
    ~TransactionDetails();

    const QDate &date() const;
    void setDate(const QDate &newDate);

    int amount() const;
    void setAmount(int newAmount);

    const QString &transactionType() const;
    void setTransactionType(const QString &newTransactionType);

    bool getTransactionStatus() const;
    void setTransactionStatus(bool newTransactionStatus);

    bool getIncomeStatus() const;
    void setIncomeStatus(bool newIncomeStatus);

    int getSerialNo() const;
    void setSerialNo(int newSerialNo);

protected:
     int m_amount;
     int serialNo;
     QString m_transactionType;
     QDate m_date;
     bool transactionStatus;
     bool incomeStatus;
signals:
     void transactionStatusChanged();
     void incomeStatusChanged();
private:
};

#endif // TRANSACTIONDETAILS_H
