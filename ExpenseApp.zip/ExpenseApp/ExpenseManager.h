#ifndef EXPENSEMANAGER_H
#define EXPENSEMANAGER_H

#include <QObject>
#include <QDebug>
#include <BaseProcessor.h>
#include <MessageProcessor.h>
#include <Contactprocessor.h>
#include <DBProcessor.h>
#include <YearModel.h>
#include <UserRegistration.h>
#include <Split.h>
#include <QCursor>
#include <GroupModel.h>
#include <QUrl>

class ExpenseManager : public QObject
{
    Q_OBJECT
    Q_PROPERTY(YearModel* yearModel READ yearModel CONSTANT)
    Q_PROPERTY(Split* split READ split CONSTANT)
    Q_PROPERTY(UserRegistration* userR READ getuserRegistration CONSTANT)
    Q_PROPERTY(BaseProcessor* messageProceessor READ getmessageProcessor CONSTANT)
    Q_PROPERTY(DBProcessor* dataBase READ getDb CONSTANT)
    Q_PROPERTY(GroupModel* groupModel READ getGroupModel CONSTANT)

    enum processor{
        TEXT=0,
        CONTACT
    };
public:
    explicit ExpenseManager(QObject *parent = nullptr);
    void init();
    ~ExpenseManager();

    Split *split() const;
    YearModel *yearModel() const;
    UserRegistration *getuserRegistration() const;
    BaseProcessor *getmessageProcessor() const;
    DBProcessor *getDb() const;
    Q_INVOKABLE void connectIncome(int yearIndex,int monthIndex);
    Q_INVOKABLE void callconnect();
    GroupModel *getGroupModel() const;
public slots:
    void receiveMessageData(QString transactionType,int amount,QDate date);
    void receiveIncomefromDB(int yindex,int mindex,int tindex,QString income);

private:
 BaseProcessor *m_messageProcessor;
 Split* m_split;
 YearModel *m_yearModel;
 UserRegistration *m_userRegistration;
 GroupModel* m_groupModel;
 DBProcessor *db;
signals:

};

#endif // EXPENSEMANAGER_H
