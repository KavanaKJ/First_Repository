#ifndef CREDITEDDETAILS_H
#define CREDITEDDETAILS_H

#include <TransactionDetails.h>
#include <QDebug>

class CreditedDetails : public TransactionDetails
{
public:
    explicit CreditedDetails();
    void print();
    ~CreditedDetails();

signals:

};

#endif // CREDITEDDETAILS_H
