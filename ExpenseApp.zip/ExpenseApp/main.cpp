#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QMutex>
#include <QFile>
#include <QDateTime>
#include <AppEngine.h>
//QScopedPointer<QFile> logfile;
//QMutex mlock;
//void messageHandler(QtMsgType type,const QMessageLogContext &context,const QString &msg);
int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif
    QGuiApplication app(argc, argv);
//    QString path = QCoreApplication::applicationDirPath();
//       qDebug()<<"path"<<path<<Qt::endl;

//       logfile.reset(new QFile(path+"/LogFile.txt"));

//       logfile.data()->open(QFile::WriteOnly | QFile ::Truncate | QFile :: Text);

//       qInstallMessageHandler(messageHandler);

    QQmlApplicationEngine engine;
    AppEngine appEngine;
    appEngine.init(&engine);
    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
//void messageHandler(QtMsgType type,const QMessageLogContext &context,const QString &msg)
//{
// mlock.lock();
// QTextStream out(logfile.data());
// out<<QDateTime::currentDateTime().toString("dd/mm/yyyy hh:mm:ss");

// switch (type)
//    {
//    case QtInfoMsg:          out<<   "Info Msg"  ; break;
//    case QtDebugMsg:     out<<  "Debug Msg" ; break;
//    case QtWarningMsg:  out<<    "Warning Msg"   ; break;
//    case QtCriticalMsg:     out<<   "Critical Msg"  ; break;
//    case QtFatalMsg:        out<<" Fatal Msg   " ; break;
//    }
//    out<<context.category <<": "<< msg <<Qt::endl;
//    out.flush();
//    mlock.unlock();
//}
