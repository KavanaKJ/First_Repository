package utils.broadcastreceivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsMessage;
import android.util.Log;
import android.database.Cursor;
import android.net.Uri;
import java.util.*;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BroadCastreceiver extends org.qtproject.qt5.android.bindings.QtActivity
{

public static String getMessage(Context c)
{

    String a="..";
    String body="",address="",date,bankMessage="";
    String message=" ";
    ArrayList<String> messagelist=new ArrayList<String>();
    System.out.println("get message called");
    Cursor cursor =c.getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null, null);
    if (cursor.moveToFirst())
    {
        do {
           String msgData = "";
           for(int idx=0;idx<cursor.getColumnCount();idx++)
           {
               msgData += " " + cursor.getColumnName(idx) + ":" + cursor.getString(idx);
                 body=cursor.getString(cursor.getColumnIndexOrThrow("body")).toString();
                 Pattern regEx = Pattern.compile("(?=.*[Aa]ccount.*|.*[Aa]/[Cc].*|.*[Aa][Cc][Cc][Tt].*|.*[Dd][Ee][Pp][Oo][Ss][Ii][Tt][Ee][Dd].*|.*[Cc][Aa][Rr][Dd].*)(?=.*[Cc]redit.*|.*[Dd]ebit.*)(?=.*[Ii][Nn][Rr].*|.*[Rr][Ss].*)(?=.*[Cc][Rr][Ee][Dd][Ii][Tt][Ee][Dd].*|.*[Dd][Ee][Bb][Ii][Tt][Ee][Dd].*)");
                    Matcher m = regEx.matcher(body);
                    if(m.find()){
//                        System.out.println("D------------"+body);
                        if(body.contains("Debited")|body.contains("debited")|body.contains("DEBITED"))
                        {
                          bankMessage=body;
                          if(bankMessage.contains(","))
                          {
                           bankMessage=bankMessage.replace(",", "");
                          }
                       date=cursor.getString(cursor.getColumnIndexOrThrow("date")).toString();
                       DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy ");
                       Calendar calendar = Calendar.getInstance();
                       long now = Long.parseLong(date);
                       calendar.setTimeInMillis(now);
                       String datefromphone = formatter.format(calendar.getTime());
                       bankMessage=datefromphone+bankMessage;
                       messagelist.add(bankMessage);
                          break;
                      }
                  if(body.contains("Credited")|body.contains("credited")|body.contains("CREDITED")|body.contains("deposited"))
                  {
                    bankMessage=body;
                    if(bankMessage.contains(","))
                    {
                     bankMessage=bankMessage.replace(",", "");
                    }
                 date=cursor.getString(cursor.getColumnIndexOrThrow("date")).toString();
                 DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                 Calendar calendar = Calendar.getInstance();
                 long now = Long.parseLong(date);
                 calendar.setTimeInMillis(now);
                 String datefromphone = formatter.format(calendar.getTime());
                 bankMessage=datefromphone+bankMessage;
                 messagelist.add(bankMessage);
                 break;
                }
             }else{
                   break;
                  }
           }
       } while (cursor.moveToNext());
    } else {
            System.out.println("No message");
    }
    for(int i=0;i<messagelist.size();i++)
    {
      message+= messagelist.get(i)+"\n";
    }
    return message;
 }
}
//([Xx\*]+|(\.\.)+)\d{3,5}-->account Number
