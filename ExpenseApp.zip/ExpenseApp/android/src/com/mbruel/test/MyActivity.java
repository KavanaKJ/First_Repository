// src/com/kdab/training/MyActivity.java
package com.mbruel.test;

import org.qtproject.qt5.android.bindings.QtActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.LocationManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

// http://supertos.free.fr/supertos.php?page=1198
public class MyActivity extends QtActivity {

        public void sendMessage(int msgId,String destMobile, String msg) {
            System.out.println("in java class method"+destMobile);
                SmsManager sms = SmsManager.getDefault();
                sms.sendTextMessage(destMobile, null, msg, null, null);
                }
}
