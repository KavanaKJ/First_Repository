package com.example.contacts.fetch;

import android.provider.ContactsContract;
import android.content.Context;
import android.database.Cursor;

public class FetchClass extends org.qtproject.qt5.android.bindings.QtActivity
{
    public FetchClass()
    {
        System.out.println("Fetch class object created");
    }
    public static String getContacts(Context c)
    {
     System.out.println("get contacts called"+c);
    String fetch="<root>";
    System.out.println("**********"+fetch);
    Cursor phones = c.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
    System.out.println("------------------"+phones);
    while (phones.moveToNext()){
        String name = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
        String phoneNumber = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
        fetch+="<item><name>"+name+"</name><number>"+phoneNumber+"</number></item>";
      }
    fetch+="</root>";
    return fetch;
    }
}
