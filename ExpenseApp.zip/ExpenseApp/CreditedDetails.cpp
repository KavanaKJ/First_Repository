#include "CreditedDetails.h"

CreditedDetails::CreditedDetails()
{
    qDebug()<<"CreditedDetails constructor"<<Qt::endl;
}

void CreditedDetails::print()
{
    qDebug()<<"---CreditedDetails--"<<Qt::endl;
}

CreditedDetails::~CreditedDetails()
{
qDebug()<<"CreditedDetails Destructor"<<Qt::endl;
}
