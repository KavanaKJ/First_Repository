#ifndef MESSAGEPROCESSOR_H
#define MESSAGEPROCESSOR_H

#include <QtAndroidExtras/QAndroidJniObject>
#include <QtAndroid>
#include <QRegularExpression>
#include <QObject>
#include <QDebug>
#include <QFile>
#include <QDate>
#include <QString>
#include <QDir>
#include <QCoreApplication>
#include <QAndroidJniEnvironment>
#include <jni.h>
class MessageProcessor : public QObject
{
    Q_OBJECT
private:
    explicit MessageProcessor();
   static MessageProcessor *messageprocessor;
public:
    void readData();
    static MessageProcessor* getInstance();
    ~MessageProcessor();
signals:
    void sendMessageData(QString transactionType,int debit,QDate date);

};

#endif // MESSAGEPROCESSOR_H
