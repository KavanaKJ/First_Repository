#ifndef CONTACTSMODEL_H
#define CONTACTSMODEL_H

#include <QtAndroidExtras/QAndroidJniObject>
#include <QtAndroid>
#include <QAbstractListModel>
#include <QDebug>
#include <QQmlEngine>
#include <Contacts.h>
#include <QDomDocument>
#include <QtXml>

class ContactsModel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(Contacts *contact READ getContact CONSTANT)
    Q_PROPERTY(QList<Contacts *> contactlist READ contactList CONSTANT)
    enum contactsDetails{
                NAME,
                PHONE
    };

public:
    explicit ContactsModel(QObject *parent = nullptr);
    void setContacts(QString name, QString phone);
    // Header:
    QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const override;
     void print();
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QHash<int, QByteArray> roleNames() const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    void sortContacts();
    ~ContactsModel();

    const QList<Contacts *> &contactList() const;
    void addContactsToList(Contacts* c);
    Contacts *getContact() const;
    void setContact(Contacts *newContact);
private:
    Contacts *contacts;
    QList<Contacts*> m_contactList;
    QList<Contacts*> m_newList;
    bool contactListStatus,contactS;
};

#endif // CONTACTSMODEL_H
