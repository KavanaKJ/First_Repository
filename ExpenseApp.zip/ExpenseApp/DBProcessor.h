#ifndef DBPROCESSOR_H
#define DBPROCESSOR_H

#include <QObject>
#include <QDebug>
#include<QtSql/QSqlDatabase>
#include<QtSql/QSqlQuery>
#include <QDir>
#include <QFile>
#include "Contacts.h"

class DBProcessor : public QObject
{
    Q_OBJECT
public:
    explicit DBProcessor(QObject *parent = nullptr);
    Q_INVOKABLE void readDataBase();
    Q_INVOKABLE void readUserDetails();
    void readTrasaction();
    void readIncome();
    Q_INVOKABLE void deleteIncomefromDB(int yindex,int mindex,int tindex,QString income);
     ~DBProcessor();
public slots:
     void receiveContacts(QString name,QString phone);
     void receiveTransaction(QString type,QString amount, QString date1);
     void receiveUserDetails(QString name,QString phone,QString password);
     void receiveIncome(int yIndex,int mIndex,int tIndex,QString income);
signals:
     void sendContacts(QString name,QString phone);
     void sendTransaction(int slno,QString type,QString amount, QString date1);
     void sendUserDetails(QString name,QString phone,QString password);
     void sendIncome(int yindex,int mindex,int tindex,QString income);
     void sendIncomeAfterDelete(int yindex,int mindex,int tindex,QString income);
private:
     QFile *file;
     int count;
     static int serialNum;
     static int serialNumforTransaction;
     static int serialNumberforIncome;

};
#endif // DBPROCESSOR_H
