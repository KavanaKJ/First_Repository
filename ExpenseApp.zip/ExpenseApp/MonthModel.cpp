#include "MonthModel.h"
MonthModel::MonthModel(QObject *parent)
    : QAbstractListModel(parent)
{
    qDebug()<<"MonthModel constructor"<<Qt::endl;
    m_currentMonthIndex=0;
    init();
//    print();
}

void MonthModel::init()
{
    for(int i=1;i<=12;i++)
    {
        m_month=new Month;
        QQmlEngine::setObjectOwnership(m_month,QQmlEngine::CppOwnership);
        m_monthList.append(m_month);
    }
      setMonthName();
}

void MonthModel::print()
{
    qDebug()<<"list size"<<m_monthList.size()<<Qt::endl;
    for(auto it=m_monthList.begin();it!=m_monthList.end();it++)
    {
        if((*it)->monthName()=="October")
        {
            for(auto i=(*it)->getTrasactionModel()->transactionList().begin();i!=(*it)->getTrasactionModel()->transactionList().end();i++)
            {
                qDebug()<<"DATE"<<(*i)->date()<<Qt::endl;
                qDebug()<<"Debited Amount"<<(*i)->amount()<<Qt::endl;
//                qDebug()<<"Total debited"<<(*i)->addTotal()<<Qt::endl;
            }
        }
        qDebug()<<"------------------"<<(*it)->monthName()<<Qt::endl;
    }
}

void MonthModel::setMessageDetails(QString transactionType,int amount,QDate date)
{
    monthName=QDate::longMonthName(date.month());
    qDebug()<<"month--"<<monthName<<Qt::endl;
    for(auto it=m_monthList.begin();it!=m_monthList.end();it++)
    {
        if((*it)->monthName()==monthName)
        {
            (*it)->setMessageDetails(transactionType,amount,date);
        }
    }
}

Month* MonthModel::getCurrentMonth()
{
 int d=QDate::currentDate().month();
  monthName=QDate::longMonthName(d);
//  qDebug()<<" current month"<<monthName<<Qt::endl;
  for(auto it=m_monthList.begin();it!=m_monthList.end();it++)
  {
      if((*it)->monthName()==monthName)
      {
          return (*it);
      }
  }
}

void MonthModel::setMonthName()
{
    int i=0;
 QList<QString> m_monthname={"January","February","March","April","May","June","July","August","September","October","November","December"};
// for(auto it=m_monthList.begin();it!=m_monthList.end();)
// {
//   for(auto m=m_monthname.begin();m!=m_monthname.end();m++)
//   {
//       (*it)->setMonthName((*m));
//       it++;
//   }
// }
 for(auto it=m_monthList.begin();it!=m_monthList.end();it++)
 {
    (*it)->setMonthName(m_monthname.at(i));
     i++;
 }
 getIndexOfCurrentMonth();

}
void MonthModel::getIndexOfCurrentMonth()
{
    int d=QDate::currentDate().month();
  QString monthN=QDate::longMonthName(d);
//  qDebug()<<"current month"<<monthN<<Qt::endl;
 for(auto it=m_monthList.begin();it!=m_monthList.end();it++)
 {
  if((*it)->monthName()!=monthN)
  {
      m_currentMonthIndex++;
  }
  else{
      break;
  }
 }
  qDebug()<<"currentMonthIndex"<<monthN<<m_currentMonthIndex<<Qt::endl;
}
void MonthModel::addTransactionDetails(int slno,QString type,QString amount, QDate date)
{
//    QDate date1= QDate::fromString(date,"dd/MM/yyyy");
    int month=date.month();
    monthName=QDate::longMonthName(month);
//    qDebug()<<"month---"<<date.month()<<endl;
    for(auto it=m_monthList.begin();it!=m_monthList.end();it++)
    {
        if((*it)->monthName()==monthName)
        {
            (*it)->transactionModel()->addTransactionDetails(slno,type,amount,date);
        }
    }
}

Month *MonthModel::getMonth(int index)
{
 Month *m =m_monthList.at(index);
 return m;
}

QVariant MonthModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    // FIXME: Implement me!
}

int MonthModel::rowCount(const QModelIndex &parent) const
{
    return m_monthList.size();
}

QVariant MonthModel::data(const QModelIndex &index, int role) const
{
    int row =index.row();
    Month *m=m_monthList.at(row);
    switch(role){
    case MONTHNAME:return m->monthName();
     }
    return QVariant();
}

QHash<int, QByteArray> MonthModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[MONTHNAME]="monthname";
    return roles;
}

int MonthModel::currentMonthIndex() const
{
 return m_currentMonthIndex;
}

MonthModel::~MonthModel()
{
    qDebug()<<"Month destructor"<<Qt::endl;
}

