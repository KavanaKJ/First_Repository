#include "DebitedDetails.h"
DebitedDetails::DebitedDetails()
{
    qDebug()<<"DebitedDetails constructor"<<Qt::endl;
}

void DebitedDetails::print()
{
    qDebug()<<"----DebitedDetails ---"<<Qt::endl;
}

DebitedDetails::~DebitedDetails()
{
    qDebug()<<"DebitedDetails Destructor"<<Qt::endl;
}



