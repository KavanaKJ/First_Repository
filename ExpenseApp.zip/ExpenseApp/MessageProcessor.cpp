#include "MessageProcessor.h"
MessageProcessor *MessageProcessor::messageprocessor=nullptr;
MessageProcessor::MessageProcessor()
{
    qDebug()<<"MessageProcessor constructor"<<Qt::endl;
}

void MessageProcessor::readData()
{
    qDebug()<<"read Message Data called"<<Qt::endl;
    auto  result = QtAndroid::checkPermission(QString("android.permission.READ_SMS"));
    if(result == QtAndroid::PermissionResult::Denied)
    {
        qDebug()<<"don't have android.permission.READ_SMS";
        QtAndroid::PermissionResultMap resultHash = QtAndroid::requestPermissionsSync(QStringList({"android.permission.READ_SMS","android.permission.RECEIVE_SMS"}));
        if(resultHash["android.permission.READ_SMS"] == QtAndroid::PermissionResult::Denied)
        {
            qDebug()<<"couldn't get android.permission.READ_SMS";
        }else{

        }
    }
    if(QAndroidJniObject::isClassAvailable("utils/broadcastreceivers/SMSBroadcastReceiver")) {
        qDebug() << "JAVA CLASS AVAILABLE!";
    }
    else {
        qDebug() << "JAVA CLASS UNAVAIABLE!";
    }
    QAndroidJniObject str = QAndroidJniObject::callStaticObjectMethod("utils/broadcastreceivers/BroadCastreceiver", "getMessage", "(Landroid/content/Context;)Ljava/lang/String;", QtAndroid::androidActivity().object<jobject>());
    qDebug()<<"Messgae---"<<str.toString()<<Qt::endl;
    QString amount,dateString;
    QDate date;
    QString debitedType="Debited",CreditedType="Credited";
    QString transactionType;
    QString allmessage=str.toString();
    QStringList message=allmessage.split("\n");
    QRegularExpressionMatch match,matchdate;
    for(int i=0;i<message.size();i++)
    {
        QRegularExpression rx("(?=[Xx|*]+|(|.|.)+)\\d{3,5}");
        match = rx.match(message[i]);
        if (match.hasMatch())
        {
            if(message[i].contains("Debited")||message[i].contains("debited")||message[i].contains("DEBITED"))
            {
                transactionType ="Debited";
                 QRegularExpression rxAmount("(?:[Ii][Nn][Rr]|[Rr][Ss])(\\s*.\\s*\\d*)");
                 match =rxAmount.match(message[i]);
                 if(match.hasMatch())
                 {
                   amount=match.captured(1);
                   amount=amount.replace(".","");
                   amount=amount.replace("-","");
                 }
                 QRegularExpression rxDate("(\\d{1,4}([.\\-/])\\d{1,2}([.\\-/])\\d{1,4})");
                 matchdate =rxDate.match(message[i]);
                 if(matchdate.hasMatch())
                 {
                     dateString = matchdate.captured(1);
                     dateString = dateString.replace("-","/");
                     dateString = dateString.replace(" ","/");
                     qDebug()<<"Date--"<<dateString<<Qt::endl;
                     QDate date1= QDate::fromString(dateString,"dd/MM/yyyy");
                     date=date1;
                 }
            }
            else if(message[i].contains("Credited")||message[i].contains("credited")||message[i].contains("CREDITED")||message[i].contains("deposited"))
            {
                qDebug()<<"Credit Message----"<<message[i]<<Qt::endl;
                transactionType="Credited";
                QRegularExpression rxAmount("(?:[Ii][Nn][Rr]|[Rr][Ss])(\\s*.\\s*\\d*)");
                match =rxAmount.match(message[i]);
                if(match.hasMatch())
                {
                    amount=match.captured(1);
                    amount=amount.replace(".","");
                    amount=amount.replace("-","");
                }
                QRegularExpression rxDate("(\\d{1,4}([.\\-/])\\d{1,2}([.\\-/])\\d{1,4})");
                matchdate =rxDate.match(message[i]);
                if(matchdate.hasMatch())
                {
                    dateString = matchdate.captured(1);
                    QDate date1= QDate::fromString(dateString,"dd/MM/yyyy");
                    date = date1;
                }
            }
            else{
            }
        }
        qDebug()<<"before signal"<<amount<<Qt::endl;
        emit MessageProcessor::getInstance()->sendMessageData(transactionType,amount.toInt(),date);
        qDebug()<<"after signal"<<Qt::endl;
    }
}

MessageProcessor *MessageProcessor::getInstance()
{
    if(messageprocessor==nullptr)
    {
     messageprocessor=new MessageProcessor;
    }
    return messageprocessor;
}

MessageProcessor::~MessageProcessor()
{
    qDebug()<<"MessageProcessor Destructor"<<Qt::endl;
}

static void getData(JNIEnv *env, jclass /*clazz*/, jstring notification)
{
    qDebug() << "get data slote called"<<notification<<Qt::endl;;
   QString nativeString = env->GetStringUTFChars(notification, 0);
    qDebug()<<"Message---"<<nativeString<<Qt::endl;
    QString amount,dateString;
    QDate date=QDate::currentDate();
    QString debitedType="Debited",CreditedType="Credited";
    QString transactionType;
    QRegularExpressionMatch match;
    QRegularExpression exp("(?=.*[Aa]ccount.*|.*[Aa]/[Cc].*|.*[Aa][Cc][Cc][Tt].*|.*[Cc][Aa][Rr][Dd].*)(?=.*[Cc]redit.*|.*[Dd]ebit.*)(?=.*[Ii][Nn][Rr].*|.*[Rr][Ss].*)(?=.*[Cc][Rr][Ee][Dd][Ii][Tt][Ee][Dd].*|.*[Dd][Ee][Bb][Ii][Tt][Ee][Dd].*)");
    match=exp.match(nativeString);
    if(match.hasMatch())
    {
        QRegularExpression rx("(?=[Xx|*]+|(|.|.)+)\\d{3,5}");
        match = rx.match(nativeString);
        if (match.hasMatch())
        {
            if(nativeString.contains("Debited")||nativeString.contains("debited")||nativeString.contains("DEBITED"))
            {
                transactionType ="Debited";
                 QRegularExpression rxAmount("(?:[Ii][Nn][Rr]|[Rr][Ss])(\\s*.\\s*\\d*)");
                 match =rxAmount.match(nativeString);
                 if(match.hasMatch())
                 {
                   amount=match.captured(1);
                   amount=amount.replace(".","");
                   amount=amount.replace("-","");
                 }
            }
            else if(nativeString.contains("Credited")||nativeString.contains("credited")||nativeString.contains("CREDITED"))
            {
                transactionType="Credited";
                QRegularExpression rxAmount("(?:[Ii][Nn][Rr]|[Rr][Ss])(\\s*.\\s*\\d*)");
                match =rxAmount.match(nativeString);
                if(match.hasMatch())
                {
                    amount=match.captured(1);
                    amount=amount.replace(".","");
                    amount=amount.replace("-","");
                }
            }
            else{

            }
        }
    }
    emit MessageProcessor::getInstance()-> sendMessageData(transactionType,amount.toInt(),date);
}
static JNINativeMethod methods[] = {
    {"getData", "(Ljava/lang/String;)V", (void *)getData}
};

jint JNICALL JNI_OnLoad(JavaVM *vm, void *) {
    JNIEnv *env;
    if (vm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_4) != JNI_OK)
        return JNI_FALSE;

    jclass clazz = env->FindClass("utils/broadcastreceivers/SMSBroadcastReceiver");
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) < 0)
        return JNI_FALSE;

    return JNI_VERSION_1_4;
}
