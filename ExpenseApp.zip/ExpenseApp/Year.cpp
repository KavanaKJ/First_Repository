#include "Year.h"

Year::Year(QObject *parent)
    : QObject{parent}
{
 qDebug()<<Q_FUNC_INFO<<"Year constructor"<<Qt::endl;
 m_monthModel=new MonthModel;
}

Year::~Year()
{
    qDebug()<<Q_FUNC_INFO<<"Year Destructor"<<Qt::endl;
}

const int &Year::getyear() const
{
    return m_year;
}

void Year::setYear(const int &newYear)
{
    m_year = newYear;
}

MonthModel *Year::monthModel() const
{
    return m_monthModel;
}
