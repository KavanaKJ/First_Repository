#include "GroupModel.h"

GroupModel::GroupModel(QObject *parent)
    : QAbstractListModel{parent}
{
 qDebug()<<Q_FUNC_INFO<<Qt::endl;
 m_selectedContactsModel= new SelectedContactsModel;
 msgid=0;
}

QVariant GroupModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
}

void GroupModel::print()
{
 for(auto it=m_groupMap.begin();it!=m_groupMap.end();it++)
 {
   qDebug()<<"group map"<<it.key()<<"value--"<<it.value()<<Qt::endl;
 }
}

int GroupModel::rowCount(const QModelIndex &parent) const
{

}
QHash<int, QByteArray> GroupModel::roleNames() const
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
}
QVariant GroupModel::data(const QModelIndex &index, int role) const
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
}

void GroupModel::addContacts(QString groupnName, SelectedContactsModel *c)
{
 for(auto it=c->getselectedContacts().begin();it!=c->getselectedContacts().end();it++)
 {
     if(m_groupMap.isEmpty())
     {
           m_groupMap.insert(groupnName,(*it));
           setContactListStatus(true);
     }else if(!m_groupMap.contains(groupnName,(*it))){
         qDebug()<<"inside else if"<<Qt::endl;
          setContactListStatus(true);
         m_groupMap.insert(groupnName,(*it));
     }else{
           setContactListStatus(false);
     }
     if((*it)->phoneNo().contains("+"))
     {
        contactNumberList.append((*it)->phoneNo());
     }else{
          contactNumberList.append("+91"+(*it)->phoneNo());
     }
 }
 sendSMS();
 print();
}

void GroupModel::sendSMS()
{
    qDebug()<<"send message called"<<Qt::endl;
    auto  result = QtAndroid::checkPermission(QString("android.permission.SEND_SMS"));
    if(result == QtAndroid::PermissionResult::Denied)
    {
        qDebug()<<"don't have android.permission.SEND_SMS";
        QtAndroid::PermissionResultMap resultHash = QtAndroid::requestPermissionsSync(QStringList({"android.permission.SEND_SMS"}));
    }
    if(QAndroidJniObject::isClassAvailable("com/mbruel/test/MyActivity")) {
        qDebug() << "JAVA CLASS AVAILABLE!";
    }
    else {
        qDebug() << "JAVA CLASS UNAVAIABLE!";
    }
    jint msgId = ++msgid;
    for(int i=0;i<contactNumberList.size();i++){
        qDebug()<<"list--"<<contactNumberList[i]<<Qt::endl;
    QAndroidJniObject myPhoneNumber = QAndroidJniObject::fromString(contactNumberList[i]);
    QAndroidJniObject myTextMessage = QAndroidJniObject::fromString("Hey! i am inviting you to install Expense Tracker https://play.google.com/apps/internaltest/4701300249989187341");
    QtAndroid::runOnAndroidThread([=]{
           QAndroidJniObject myJavaObject("com/mbruel/test/MyActivity");
           myJavaObject.callMethod<void>("sendMessage", "(ILjava/lang/String;Ljava/lang/String;)V",
                                                                         msgId,
                                                                    myPhoneNumber.object<jstring>(),
                                                                    myTextMessage.object<jstring>());
       });
    }
   contactNumberList.clear();
}
GroupModel::~GroupModel()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
}

const QString &GroupModel::groupName() const
{
    return m_groupName;
}

void GroupModel::setGroupName(const QString &newGroupName)
{
    m_groupName = newGroupName;
}

SelectedContactsModel *GroupModel::getSelectedContactsModel() const
{
    return m_selectedContactsModel;
}

bool GroupModel::getContactListStatus() const
{
    return contactListStatus;
}

void GroupModel::setContactListStatus(bool newContactListStatus)
{
    if (contactListStatus == newContactListStatus)
        return;
    contactListStatus = newContactListStatus;
    emit contactListStatusChanged();
}
