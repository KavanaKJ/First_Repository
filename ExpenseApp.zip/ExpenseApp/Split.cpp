#include "Split.h"

Split::Split(QObject *parent)
    : QAbstractListModel(parent)
{
    qDebug()<<"Split constructor"<<Qt::endl;
    m_contactModel=new ContactsModel;
}

void Split::setContact(QString name, QString phone)
{
    m_contactModel->setContacts(name,phone);
}

void Split::createGroup(Contacts* c)
{
    qDebug()<<Q_FUNC_INFO<<"createGroup called"<<Qt::endl;
    if(m_contactsgroup.isEmpty())
    {
        m_contactsgroup.append(c);
    }
    else
    {
            if(m_contactsgroup.contains(c))
            {
                qDebug()<<"list already has object"<<Qt::endl;
            }
            else{
                m_contactsgroup.append(c);
            }
    }
    qDebug()<<"size---"<<m_contactsgroup.size()<<Qt::endl;
}

void Split::removeContactsfromGroup(Contacts *c)
{
    if(m_contactsgroup.contains(c))
    {
     m_contactsgroup.removeOne(c);
     qDebug()<<"object deleted---"<<m_contactsgroup.size()<<Qt::endl;
    }
}

void Split::splitAmount(QString amount)
{
    if(m_contactsgroup.isEmpty())
    {
      setContactListStatus(true);
        qDebug()<<"list is empty--"<<m_contactListStatus<<Qt::endl;

    }else{
        setContactListStatus(false);
        amount = amount.replace("₹ ","");
        amount = amount.replace(".00","");
        int s=amount.toInt()/m_contactsgroup.size();
        qDebug()<<"splitted amount--"<<s<<" "<<m_contactListStatus<<Qt::endl;
        for(auto it=m_contactsgroup.begin();it!=m_contactsgroup.end();it++)
        {
            (*it)->setSplittedAmount(s);
        }
    }
}

void Split::deleteSelectedContacts()
{
    if(m_contactsgroup.isEmpty())
    {
        qDebug()<<"list is empty"<<Qt::endl;
    }else{
    m_contactsgroup.clear();
    }
    qDebug()<<"size of group--"<<m_contactsgroup.size()<<Qt::endl;
    qDebug()<<"size of contact list--"<<m_contactModel->contactList().size()<<Qt::endl;
}

int Split::rowCount(const QModelIndex &parent) const
{
    return m_contactsgroup.size();
}

QHash<int, QByteArray> Split::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[NAME]="contactName";
    roles[PHONE]="phoneNo";
    roles[AMOUNT]="splittedamount";
    return roles;
}

QVariant Split::data(const QModelIndex &index, int role) const
{
    int row =index.row();
    Contacts *c = m_contactsgroup.at(row);
    switch(role)
    {
    case NAME:return c->name();
    case PHONE:return c->phoneNo();
    case AMOUNT:return c->splittedAmount();
    }
    return QVariant();
}
Split::~Split()
{
    qDebug()<<"Split Destructor"<<Qt::endl;
}

ContactsModel *Split::contactModel() const
{
    return m_contactModel;
}

bool Split::getContactListStatus() const
{
    return m_contactListStatus;
}

void Split::setContactListStatus(bool newContactListStatus)
{
    if (m_contactListStatus == newContactListStatus)
        return;
    m_contactListStatus = newContactListStatus;
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    emit contactListStatusChanged();
}

