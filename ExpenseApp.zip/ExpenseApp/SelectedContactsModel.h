#ifndef SELECTEDCONTACTSMODEL_H
#define SELECTEDCONTACTSMODEL_H

#include <QAbstractListModel>
#include <QObject>
#include <QDebug>
#include <Contacts.h>

class SelectedContactsModel : public QAbstractListModel
{
    Q_OBJECT
    enum contactsDetails{
                NAME,
                PHONE
    };
public:
    explicit SelectedContactsModel(QObject *parent = nullptr);
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QHash<int, QByteArray> roleNames() const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    Q_INVOKABLE void getContactDetail(Contacts* c);
    void print();
    ~SelectedContactsModel();
    const QList<Contacts *> &getselectedContacts() const;
    Q_INVOKABLE void removeContactsfromGroup(Contacts *c);

signals:

private:
  QList<Contacts*> m_selectedContacts;

};

#endif // SELECTEDCONTACTSMODEL_H
