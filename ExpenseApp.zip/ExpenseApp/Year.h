#ifndef YEAR_H
#define YEAR_H

#include <QObject>
#include <QDebug>
#include <MonthModel.h>

class Year : public QObject
{
    Q_OBJECT
    Q_PROPERTY(MonthModel* monthModel READ monthModel CONSTANT)
    Q_PROPERTY(int year READ getyear CONSTANT)
public:
    explicit Year(QObject *parent = nullptr);
    ~Year();
    const int &getyear() const;
    void setYear(const int &newYear);
    MonthModel *monthModel() const;

private:
    int m_year;
    MonthModel *m_monthModel;
signals:
};

#endif // YEAR_H
