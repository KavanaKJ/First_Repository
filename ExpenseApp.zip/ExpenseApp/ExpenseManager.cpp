#include "ExpenseManager.h"

ExpenseManager::ExpenseManager(QObject *parent)
    : QObject{parent}
{
    qDebug()<<"ExpenseManager constructor"<<Qt::endl;
    m_userRegistration=new UserRegistration;
    m_yearModel=new YearModel;
    db = new DBProcessor;
    m_groupModel =new GroupModel;
    m_split = new Split;
    init();
}

void ExpenseManager::init()
{

    MessageProcessor *message= MessageProcessor::getInstance();
    connect(message,SIGNAL(sendMessageData(QString,int,QDate)),this,SLOT(receiveMessageData(QString ,int ,QDate)));
    MessageProcessor::getInstance()->readData();
    m_messageProcessor=new Contactprocessor;
    connect(m_messageProcessor,&BaseProcessor::sendContactData,db,&DBProcessor::receiveContacts);
    m_messageProcessor->readData();
    connect(db,&DBProcessor::sendContacts,m_split->contactModel(),&ContactsModel::setContacts);
    db->readDataBase();
    connect(m_yearModel,&YearModel::sendTransaction,db,&DBProcessor::receiveTransaction);
    connect(db,&DBProcessor::sendTransaction,m_yearModel,&YearModel::addTransactiontoModel);
    db->readTrasaction();
    connect(m_userRegistration,&UserRegistration::sendUserDetails,db,&DBProcessor::receiveUserDetails);
    connect(db,&DBProcessor::sendUserDetails,m_userRegistration,&UserRegistration::addUserDetails);
    db->readUserDetails();
    connect(db,&DBProcessor::sendIncome,m_yearModel,&YearModel::addIncome);
    db->readIncome();
    connect(db,&DBProcessor::sendIncomeAfterDelete,this,&ExpenseManager::receiveIncomefromDB);

}

ExpenseManager::~ExpenseManager()
{
    qDebug()<<"ExpenseManager Destructor"<<Qt::endl;
}

void ExpenseManager::receiveMessageData(QString transactionType,int amount,QDate date)
{
    qDebug()<<"receive slot"<<Qt::endl;
    m_yearModel->setMessageDetails(transactionType,amount,date);
}

void ExpenseManager::receiveIncomefromDB(int yindex, int mindex, int tindex, QString income)
{
 m_yearModel->removeIncome(yindex,mindex,tindex,income);
}
GroupModel *ExpenseManager::getGroupModel() const
{
    return m_groupModel;
}
DBProcessor *ExpenseManager::getDb() const
{
    return db;
}

void ExpenseManager::connectIncome(int yearIndex, int monthIndex)
{
    connect(m_yearModel->getYearObj(yearIndex)->monthModel()->getMonth(monthIndex)->transactionModel(),&TransactionModel::sendIncome,db,&DBProcessor::receiveIncome);
}

void ExpenseManager::callconnect()
{
    qDebug()<<"call connect called"<<Qt::endl;
    connect(db,&DBProcessor::sendIncome,m_yearModel,&YearModel::addIncome);
    db->readIncome();
}

BaseProcessor *ExpenseManager::getmessageProcessor() const
{
    return m_messageProcessor;
}

UserRegistration *ExpenseManager::getuserRegistration() const
{
    return m_userRegistration;
}

YearModel *ExpenseManager::yearModel() const
{
    return m_yearModel;
}

Split *ExpenseManager::split() const
{
    return m_split;
}

