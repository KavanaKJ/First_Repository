#ifndef USER_H
#define USER_H

#include <QObject>
#include <QDebug>

class User : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString name READ userName CONSTANT)
    Q_PROPERTY(QString phoneNo READ phoneNumber CONSTANT)
public:
    explicit User(QObject *parent = nullptr);
    ~User();
    QString phoneNumber() const;
    void setPhoneNumber(QString newPhoneNumber);

    const QString &userName() const;
    void setUserName(const QString &newUserName);

    const QString &passWord() const;
    void setPassWord(const QString &newPassWord);

signals:
private:
    QString m_phoneNumber;
    QString m_userName;
    QString m_passWord;
};

#endif // USER_H
