#include "DBProcessor.h"
int DBProcessor::serialNum=1;
int DBProcessor::serialNumforTransaction=1;
int DBProcessor::serialNumberforIncome=1;
DBProcessor::DBProcessor(QObject *parent)
    : QObject{parent}
{
    qDebug()<<Q_FUNC_INFO<<"DBProcessor Constructor"<<Qt::endl;
    file =new QFile;
    count=0;
}

void DBProcessor::readDataBase()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");
    QString currentpathcontact=QDir::currentPath()+"/ContactsData.db";
    qDebug()<<"path***********"<<currentpathcontact<<Qt::endl;
    file->setFileName(currentpathcontact);
    file->open(QIODevice::ReadWrite);
    db.setDatabaseName(currentpathcontact);
    if(db.open()){
        qDebug()<<"DB Connected Successfully ContactsData"<<Qt::endl;
        QSqlQuery qr(db);
        qr.prepare("select *from Contactsdata");
        if(qr.exec()){
            while (qr.next())
            {
                QString name = qr.value(0).toString();
                QString phone = qr.value(1).toString();
                count++;
                qDebug()<<"contacts count"<<count<<Qt::endl;
                emit sendContacts(name,phone);
            }
        }
        else{
            qDebug()<<"ContactsData can't execute Read Query"<<Qt::endl;
        }
    }
    else{
        qDebug()<<"DB not Connected "<<Qt::endl;
    }
    db.close();
}

void DBProcessor::readUserDetails()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    //      QFile file;
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");
    QString currentpath=QDir::currentPath()+"/UserDB.db";
    file->setFileName(currentpath);
    file->open(QIODevice::ReadWrite);
    db.setDatabaseName(currentpath);
    if(db.open()){
        qDebug()<<"UserDB Connected Successfully"<<Qt::endl;
        QSqlQuery qr(db);
        qr.prepare("select *from UserData");
        if(qr.exec()){
            while (qr.next())
            {
                int serialNum1 =qr.value(0).toInt();
                QString name = qr.value(1).toString();
                QString phone = qr.value(2).toString();
                QString password = qr.value(3).toString();
                qDebug()<<"UserData Fetched Successfully"<<serialNum1<<name<<phone<<password<<Qt::endl;
                emit sendUserDetails(name,phone,password);
            }
        }
        else{
            qDebug()<<"can't execute user Read Query"<<Qt::endl;
        }
    }
}

void DBProcessor::readTrasaction()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    QString type,amount,date;
    int slno;
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");
    QString Trasactioncurrentpath=QDir::currentPath()+"/Transaction.db";
    qDebug()<<"path*********** readTrasaction"<<Trasactioncurrentpath<<Qt::endl;
    file->setFileName(Trasactioncurrentpath);
    file->open(QIODevice::ReadWrite);
    db.setDatabaseName(Trasactioncurrentpath);
    if(db.open()){
        qDebug()<<"DB Connected Successfully"<<Qt::endl;
        QSqlQuery qr(db);
        qr.prepare("select *from Transactiondata");
        if(qr.exec()){
            while (qr.next())
            {
                slno =qr.value(0).toInt();
                type = qr.value(1).toString();
                amount = qr.value(2).toString();
                date = qr.value(3).toString();
                serialNumforTransaction=slno+1;
                qDebug()<<"read transaction"<<slno<<type<<amount<<Qt::endl;
                emit sendTransaction(slno,type,amount,date);
            }
        }
        else{
            qDebug()<<"Transactiondata can't execute Read Query"<<Qt::endl;
        }
    }
    else{
        qDebug()<<"DB not Connected "<<Qt::endl;
    }
    db.close();
}

void DBProcessor::readIncome()
{
    qDebug()<<"read income from database"<<Qt::endl;
    int yindex,mindex,tindex,slno;
    QString income;
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");
    QString currentpath=QDir::currentPath()+"/IncomeDB.db";
    file->setFileName(currentpath);
    file->open(QIODevice::ReadWrite);
    db.setDatabaseName(currentpath);
    if(db.open()){
        qDebug()<<"income DB Connected Successfully"<<Qt::endl;
        QSqlQuery qr(db);
        qr.prepare("select *from Income");
        if(qr.exec()){
            while (qr.next())
            {
                qDebug()<<"inside income while"<<Qt::endl;
                slno = qr.value(0).toInt();
                yindex = qr.value(1).toInt();
                mindex =qr.value(2).toInt();
                tindex =qr.value(3).toInt();
                income =qr.value(4).toString();
                serialNumberforIncome=slno+1;
                qDebug()<<"inside income while"<<slno<<yindex<<mindex<<income<<Qt::endl;
                emit sendIncome(yindex,mindex,tindex,income);
            }
        }else{
            qDebug()<<"Income can't execute Read Query"<<Qt::endl;
        }
    }else{
      qDebug()<<"DB not Connected "<<Qt::endl;
    }
    db.close();
}

void DBProcessor::deleteIncomefromDB(int yindex,int mindex,int tindex,QString income)
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    income = income.replace("₹","");
    income = income.replace(".00","");
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");
    QString currentpath=QDir::currentPath()+"/IncomeDB.db";
    file->setFileName(currentpath);
    file->open(QIODevice::ReadWrite);
    db.setDatabaseName(currentpath);
    if(db.open()){
      QSqlQuery qr(db);
      qr.prepare("DELETE FROM Income WHERE yearindex=(:yearindex) AND monthindex=(:monthindex) AND transactionindex=(:transactionindex) AND income=(:income)");
      qr.bindValue(":yearindex",yindex);
      qr.bindValue(":monthindex",mindex);
      qr.bindValue(":transactionindex",tindex);
      qr.bindValue(":income",income);
     emit sendIncomeAfterDelete(yindex,mindex,tindex,income);
      if(qr.exec()){
      qDebug()<<"delete executed"<<Qt::endl;
      }else{
          qDebug()<<"delete not executed"<<Qt::endl;
      }
    }
    db.close();
}
void DBProcessor::receiveContacts(QString name,QString phone)
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");
    QString Contactscurrentpath=QDir::currentPath()+"/ContactsData.db";
    qDebug()<<"path***********"<<Contactscurrentpath<<Qt::endl;
    file->setFileName(Contactscurrentpath);
    file->open(QIODevice::ReadWrite);
    db.setDatabaseName(Contactscurrentpath);
    if(db.open()){
        qDebug()<<"DB Connected Successfully"<<Qt::endl;
        QSqlQuery qr(db);
        //          qr.prepare("delete from Contactsdata");
        QString qry("CREATE TABLE Contactsdata(name VARCHAR[50] ,phone VARCHAR[15] UNIQUE)");
        if(qr.exec(qry)){
            qDebug() << "Table Created" <<Qt::endl;
        }
        else{
            qDebug() << "Table Not Created" <<Qt::endl;
        }
        qr.prepare("insert into Contactsdata(name , phone)  values( ? , ?) ");
        qr.bindValue(0 , name);
        qr.bindValue(1 , phone);
        if(qr.exec()){
            qDebug()<<"Contacts stored Successfully"<<Qt::endl;
        }
        else{
            qDebug()<<" Contacts can't execute write Query"<<Qt::endl;
        }
    }
    else{
        qDebug()<<"DB not Connected "<<Qt::endl;
    }
    db.close();
}

void DBProcessor::receiveTransaction(QString type, QString amount, QString date1)
{
    qDebug()<<Q_FUNC_INFO<<"receiveTransaction called"<<Qt::endl;
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");
    QString currentpath1=QDir::currentPath()+"/Transaction.db";
    qDebug()<<"path*********** of transaction database write"<<currentpath1<<Qt::endl;
    file->setFileName(currentpath1);
    file->open(QIODevice::ReadWrite);
    db.setDatabaseName(currentpath1);
    if(db.open())
    {
        qDebug()<<"DB connected Successfully Transaction Write"<<Qt::endl;
        QSqlQuery qr(db);
        QString qry("CREATE TABLE Transactiondata(slno INTEGER PRIMARY KEY, type VARCHAR[20] ,amount VARCHAR[20],date VARCHAR[20])");
        if(qr.exec(qry)){
            qDebug() << " Transaction Table Created write" <<Qt::endl;
        }else{
            qDebug() << " Transaction Table Not Created write" <<Qt::endl;
        }
        qr.prepare("insert into Transactiondata(slno,type,amount,date) values(?,? ,? ,?)");
        qr.bindValue(0,serialNumforTransaction);
        qr.bindValue(1,type);
        qr.bindValue(2,amount);
        qr.bindValue(3,date1);
        if(qr.exec()){
            qDebug()<<"Transaction stored Successfully"<<Qt::endl;
        }else{
            qDebug()<<"Transaction can't execute write Query"<<Qt::endl;
        }
    }else{
        qDebug()<<"DB not Connected "<<Qt::endl;
    }
    readTrasaction();
    db.close();
}

void DBProcessor::receiveUserDetails(QString name, QString phone, QString password)
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");
    QString currentpath=QDir::currentPath()+"/UserDB.db";
    file->setFileName(currentpath);
    file->open(QIODevice::ReadWrite);
    db.setDatabaseName(currentpath);
    if(db.open()){
        qDebug()<<"UserDB Connected Successfully"<<Qt::endl;
        QSqlQuery qr(db);
        QString qry("CREATE TABLE UserData(slNo INTEGER PRIMARY KEY ,  Name VARCHAR[20],Phone VARCHAR[20] , Password VARCHAR[20])");
        if(qr.exec(qry)){
            qDebug() << " user Table Created" <<Qt::endl;
        }
        else{
            qDebug() << "user Table Not Created" <<Qt::endl;
        }
        qr.prepare("insert into UserData (slNo , Name , Phone , Password)  values( ? , ?  , ? , ? )");
        qr.bindValue(0 , serialNum);
        qr.bindValue(1 , name);
        qr.bindValue(2 ,  phone);
        qr.bindValue(3 , password);
        if(qr.exec()){
            qDebug()<<"Userdata stored Successfully"<<Qt::endl;
        }
        else{
            qDebug()<<"can't execute write Query"<<Qt::endl;
        }
    }
    else{
        qDebug()<<"DB not Connected "<<Qt::endl;
    }
    db.close();
}

void DBProcessor::receiveIncome(int yIndex,int mIndex,int tIndex,QString income)
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    QString currentpath=QDir::currentPath()+"/IncomeDB.db";
    file->setFileName(currentpath);
    file->open(QIODevice::ReadWrite);
    db.setDatabaseName(currentpath);
    if(db.open())
    {
        QSqlQuery qr(db);
        QString qry("CREATE TABLE Income(slNo INTEGER PRIMARY KEY,yearindex INTEGER,monthindex INTEGER,transactionindex INTEGER,income VARCHAR[20])");
        if(qr.exec(qry)){
            qDebug()<<"Income table created"<<Qt::endl;
        }else{
            qDebug()<<"Income table not created"<<Qt::endl;
        }
        qr.prepare("insert into Income (slNo,yearindex,monthindex,transactionindex,income) values(?,?,?,?,?)");
        qr.bindValue(0,serialNumberforIncome);
        qr.bindValue(1,yIndex);
        qr.bindValue(2,mIndex);
        qr.bindValue(3,tIndex);
        qr.bindValue(4,income);
//        qr.prepare("delete from Income");
//        qr.prepare("drop table income");
        if(qr.exec()){
            qDebug()<<"Income stored successfully"<<Qt::endl;
        }else{
            qDebug()<<"cannot execute income write query"<<Qt::endl;
        }
    }else{
        qDebug()<<"DB not connected"<<Qt::endl;
    }
    db.close();
}
DBProcessor::~DBProcessor()
{
    qDebug()<<Q_FUNC_INFO<<"DBProcessor Destructor"<<Qt::endl;
}
