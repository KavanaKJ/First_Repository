#include "Contacts.h"

Contacts::Contacts(QObject *parent)
    : QObject{parent}
{
    qDebug()<<"Contacts constructor"<<Qt::endl;
    setSelectedContact(false);
}

Contacts::~Contacts()
{
    qDebug()<<"Contacts Destructor"<<Qt::endl;
}

int Contacts::splittedAmount() const
{
    return m_splittedAmount;
}

void Contacts::setSplittedAmount(int newSplittedAmount)
{
    m_splittedAmount = newSplittedAmount;
}

bool Contacts::selectedContact() const
{
    return m_selectedContact;
}

void Contacts::setSelectedContact(bool newSelectedContact)
{
    qDebug()<<Q_FUNC_INFO<<"-------"<<newSelectedContact<<Qt::endl;
    m_selectedContact = newSelectedContact;
    emit onselectedContacts();
}

const QString &Contacts::name() const
{
    return m_name;
}

void Contacts::setName(const QString &newName)
{
    m_name = newName;
}

const QString &Contacts::phoneNo() const
{
    return m_phoneNo;
}

void Contacts::setPhoneNo(const QString &newPhoneNo)
{
    m_phoneNo = newPhoneNo;
}
