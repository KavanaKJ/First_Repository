#ifndef TRANSACTIONMODEL_H
#define TRANSACTIONMODEL_H

#include <QAbstractListModel>
#include <QDebug>
#include <TransactionDetails.h>
#include <CreditedDetails.h>
#include <DebitedDetails.h>
#include <QQmlEngine>

class TransactionModel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(int totaldebit READ gettotalDebit WRITE setTotalDebit NOTIFY totaldebitChanged)
    Q_PROPERTY(int income READ getTotalIncome WRITE setTotalIncome NOTIFY incomeChanged)
    Q_PROPERTY( QList<TransactionDetails *> transactionlist READ transactionList CONSTANT)
    enum TransactionData{
         AMOUNT=1,
         TYPE,
         DATE,
        TOTALDEBIT
    };

public:
    explicit TransactionModel(QObject *parent = nullptr);
    void setMessage(QString transactionType,int amount,QDate date);
    void print();
    void addTransactionDetails(int slno,QString type,QString amount,QDate date);
    QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const override;
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QHash<int, QByteArray> roleNames() const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    ~TransactionModel();
    const QList<TransactionDetails *> &transactionList() const;
    int gettotalDebit();
    Q_INVOKABLE void totalIncome(int yIndex,int mIndex,int tIndex,QString income);
    Q_INVOKABLE void deleteFromIncome(int income);
    Q_INVOKABLE TransactionDetails* getTransactionObj(int index);
    void setTotalDebit(int newTotalDebit);
    int getTotalIncome();
    void setTotalIncome(int newTotalIncome);
    void setincome(int income);

private:
     int m_totalDebit;
     int m_income;
     TransactionDetails *m_transaction;
    QList<TransactionDetails*> m_transactionList;
signals:
    void totaldebitChanged();
    void incomeChanged();
    void sendIncome(int yindex,int mindex,int tindex,QString income);
};

#endif // TRANSACTIONMODEL_H
