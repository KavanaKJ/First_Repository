#ifndef SPLIT_H
#define SPLIT_H

#include <QAbstractListModel>
#include <QDebug>
#include <ContactsModel.h>
#include <Contacts.h>

class Split : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(ContactsModel* contactModel READ contactModel CONSTANT)
    Q_PROPERTY(bool contactListStatus READ getContactListStatus WRITE setContactListStatus NOTIFY contactListStatusChanged)
    enum contactsDetails{
                NAME,
                PHONE,
               AMOUNT
    };
public:
    explicit Split(QObject *parent = nullptr);
    void setContact(QString name, QString phone);
    Q_INVOKABLE void createGroup(Contacts* c);
    Q_INVOKABLE void removeContactsfromGroup(Contacts* c);
    Q_INVOKABLE void splitAmount(QString amount);
    Q_INVOKABLE void deleteSelectedContacts();
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QHash<int, QByteArray> roleNames() const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    ~Split();
    ContactsModel *contactModel() const;

    bool getContactListStatus() const;
    void setContactListStatus(bool newContactListStatus);

private:
   ContactsModel *m_contactModel;
   QList<Contacts*> m_contactsgroup;
   bool m_contactListStatus;

signals:
   void selectedContactChanged();

   void contactListStatusChanged();
};

#endif // SPLIT_H
