#ifndef CONTACTS_H
#define CONTACTS_H

#include <QObject>
#include <QDebug>

class Contacts : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool contactStatus READ selectedContact WRITE setSelectedContact NOTIFY onselectedContacts)
public:
    explicit Contacts(QObject *parent = nullptr);
    const QString &name() const;
    void setName(const QString &newName);

    const QString &phoneNo() const;
    void setPhoneNo(const QString &newPhoneNo);
    ~Contacts();

    int splittedAmount() const;
    void setSplittedAmount(int newSplittedAmount);

    bool selectedContact() const;
    void setSelectedContact(bool newSelectedContact);

private:
    bool m_selectedContact;
    QString m_name;
    QString m_phoneNo;
    int m_splittedAmount;
signals:
    void onselectedContacts();
};

#endif // CONTACTS_H
