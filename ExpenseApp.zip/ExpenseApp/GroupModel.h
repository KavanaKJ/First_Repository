#ifndef GROUPMODEL_H
#define GROUPMODEL_H

#include <QAbstractListModel>
#include <QObject>
#include <Contacts.h>
#include <SelectedContactsModel.h>
#include <QtAndroidExtras/QAndroidJniObject>
#include <QtAndroid>
#include <QDebug>

class GroupModel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(SelectedContactsModel* selectedContactsModel READ getSelectedContactsModel CONSTANT)
    Q_PROPERTY(bool contactListStatus READ getContactListStatus WRITE setContactListStatus NOTIFY contactListStatusChanged)
public:
    explicit GroupModel(QObject *parent = nullptr);
    QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const override;
     void print();
     int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QHash<int, QByteArray> roleNames() const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    Q_INVOKABLE void addContacts(QString groupnName,SelectedContactsModel* c);
    void sendSMS();
    ~GroupModel();
    const QString &groupName() const;
    void setGroupName(const QString &newGroupName);
    SelectedContactsModel *getSelectedContactsModel() const;

    bool getContactListStatus() const;
    void setContactListStatus(bool newContactListStatus);

signals:
    void contactListStatusChanged();

private:
  QString m_groupName;
  QMultiMap<QString,Contacts*> m_groupMap;
  SelectedContactsModel *m_selectedContactsModel;
  int msgid;
  QList<QString> contactNumberList;
  bool contactListStatus;
};

#endif // GROUPMODEL_H
