#ifndef APPENGINE_H
#define APPENGINE_H

#include <QObject>
#include <QDebug>
#include <ExpenseManager.h>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <YearModel.h>
#include <Year.h>
#include <MonthModel.h>
#include <Month.h>
#include <TransactionModel.h>
#include <TransactionDetails.h>
#include <Split.h>
#include <DBProcessor.h>
#include <UserRegistration.h>
#include <ContactsModel.h>
#include <GroupModel.h>
#include <SelectedContactsModel.h>
#include <MessageProcessor.h>

class AppEngine : public QObject
{
    Q_OBJECT
public:
    explicit AppEngine(QObject *parent = nullptr);
    void init(QQmlApplicationEngine* engine);
    ~AppEngine();

signals:

};

#endif // APPENGINE_H
