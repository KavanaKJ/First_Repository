#ifndef MONTHMODEL_H
#define MONTHMODEL_H

#include <QAbstractListModel>
#include <QDebug>
#include <QQmlEngine>
#include <Month.h>
enum Months{
   MONTHNAME=1
};

class MonthModel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(Month* monthobj READ getCurrentMonth CONSTANT)
    Q_PROPERTY(int currentMonthIndex READ currentMonthIndex CONSTANT)

public:
    explicit MonthModel(QObject *parent = nullptr);

    void init();
    void print();
    void setMessageDetails(QString transactionType,int amount,QDate date);
     Month* getCurrentMonth();
     void setMonthName();
      void addTransactionDetails(int slno,QString type,QString amount,QDate date);
     Q_INVOKABLE Month* getMonth(int index);
    // Header:
    QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const override;
    // Basic functionality:
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;
    int currentMonthIndex() const;
    void getIndexOfCurrentMonth();
    ~MonthModel();

private:
     QString monthName;
     int m_currentMonthIndex;
     Month *m_month;
     QList<Month*> m_monthList;
};

#endif // MONTHMODEL_H
