#include "BaseProcessor.h"

BaseProcessor::BaseProcessor(QObject *parent)
    : QObject{parent}
{
    qDebug()<<"BaseProcessor constructor"<<Qt::endl;
}

BaseProcessor::~BaseProcessor()
{
    qDebug()<<"BaseProcessor Destructor"<<Qt::endl;
}
